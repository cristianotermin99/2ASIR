from domain.modelo.Carta import Carta
from ui.main.main import main




if ( __name__ == "__main__" )   : 
    main()